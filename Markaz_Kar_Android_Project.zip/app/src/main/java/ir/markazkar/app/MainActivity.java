package ir.markazkar.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(16, 27, 53);
    private final int teal = Color.rgb(61, 214, 198);
    private final int ink = Color.rgb(30, 42, 66);
    private TextView vpnState;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(244, 247, 251));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(page);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(18), dp(18), dp(18));
        header.setBackground(round(navy, 22));
        TextView logo = text("▦", 34, teal, true);
        header.addView(logo);
        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, 0, 0);
        titleCol.addView(text("مرکز کار", 25, Color.WHITE, true));
        titleCol.addView(text("مدیریت ارتباطات محل کار", 13, 0xFFCAD4E5, false));
        header.addView(titleCol);
        page.addView(header, params(-1, -2));

        addGap(page, 16);
        LinearLayout vpn = card(page, "اتصال امن");
        vpnState = text("وضعیت: آماده اتصال", 15, ink, true);
        vpn.addView(vpnState);
        addGap(vpn, 10);
        Button connect = button("اتصال VPN");
        connect.setOnClickListener(v -> Toast.makeText(this,
            "اتصال VPN هنوز پیکربندی نشده است.", Toast.LENGTH_LONG).show());
        vpn.addView(connect, params(-1, dp(48)));
        addGap(vpn, 8);
        vpn.addView(text("IP محل کار: 185.158.172.150", 13, 0xFF64748B, false));

        addGap(page, 14);
        LinearLayout pc = card(page, "کامپیوترهای محل کار");
        pc.addView(text("۱۵ دستگاه قابل تعریف • جست‌وجو و اتصال در نسخه‌های بعدی", 13, 0xFF64748B, false));
        addGap(pc, 8);
        for (int i=1; i<=5; i++) {
            TextView row = text(String.format("کامپیوتر %02d     •     آدرس شبکه پس از تنظیم وارد می‌شود", i), 14, ink, false);
            row.setPadding(0, dp(8), 0, dp(8));
            pc.addView(row);
        }
        Button morePc = button("نمایش فهرست ۱۵ کامپیوتر");
        morePc.setOnClickListener(v -> Toast.makeText(this, "فهرست دستگاه‌ها هنوز باید تکمیل شود.", Toast.LENGTH_SHORT).show());
        pc.addView(morePc, params(-1, dp(44)));

        addGap(page, 14);
        LinearLayout cameras = card(page, "دوربین‌های Dahua");
        cameras.addView(text("دستگاه ضبط: 192.168.10.18", 14, ink, true));
        addGap(cameras, 6);
        cameras.addView(text("انتخاب چیدمان دوربین‌ها", 13, 0xFF64748B, false));
        addGap(cameras, 8);
        LinearLayout grids = new LinearLayout(this);
        grids.setOrientation(LinearLayout.HORIZONTAL);
        for (String s : new String[]{"۱", "۴", "۹", "۱۶", "۳۲"}) {
            Button b = button(s);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1);
            p.setMargins(dp(3), 0, dp(3), 0);
            grids.addView(b, p);
            b.setOnClickListener(v -> Toast.makeText(this, "نمایش زنده پس از اتصال به NVR فعال می‌شود.", Toast.LENGTH_SHORT).show());
        }
        cameras.addView(grids);

        addGap(page, 14);
        LinearLayout note = card(page, "درباره این نسخه");
        note.addView(text("این فایل، نسخه اولیه رابط کاربری است. اتصال واقعی VPN، کنترل کامپیوترها و پخش زنده دوربین‌ها هنوز به تنظیمات شبکه و پیاده‌سازی فنی نیاز دارند.", 13, 0xFF64748B, false));

        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent, String heading) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(round(Color.WHITE, 18));
        parent.addView(box, params(-1, -2));
        box.addView(text(heading, 18, navy, true));
        addGap(box, 10);
        return box;
    }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setLineSpacing(dp(3), 1f);
        return t;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(13); b.setTextColor(navy);
        b.setAllCaps(false);
        b.setBackground(round(teal, 14));
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(dp(radius));
        return d;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private void addGap(LinearLayout l, int h) { View v = new View(this); l.addView(v, params(1, dp(h))); }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
