ALI SHAMS CONTROL - Android project

امکانات:
- چهار پروفایل VNC با اتصال واقعی RFB 3.8، رمز کلاسیک VNC و نمایش تصویر (حالت فقط نمایش)
- اتصال تکی و حالت چهار پنجره همزمان
- ذخیره IP، پورت و رمز هر سیستم
- ثبت چهار ورودی Hikvision و بازکردن RTSP در پخش‌کننده نصب‌شده روی گوشی
- ذخیره و بازکردن ۱۲ وب‌سایت
- راهنمای راه‌اندازی VNC و VPN

محدودیت‌ها و پیش‌نیازها:
- روی هر کامپیوتر ویندوز باید جداگانه VNC Server نصب و اجرا شود؛ این اپلیکیشن VNC Viewer است.
- در VNC Server، رمز VNC کلاسیک و در صورت امکان Raw encoding را فعال کنید. پورت پیش‌فرض 5900 است.
- این پیاده‌سازی RFB 3.8، VNC Authentication و Raw framebuffer را پشتیبانی می‌کند. رمزهای امنیتی TLS/VeNCrypt و encodingهای فشرده در این نسخه پشتیبانی نمی‌شوند.
- برای نمایش تصویر، سرور VNC باید Raw encoding را بپذیرد. اگر سرور فقط Tight/ZRLE را ارائه کند، اتصال خطای encoding می‌دهد.
- حالت چهارگانه چهار اتصال جداگانه باز می‌کند و مصرف شبکه/پردازنده بیشتر است.
- بخش دوربین فقط RTSP را به پلیر خارجی می‌فرستد؛ پخش داخلی ندارد.
- بخش WireGuard در این نسخه راهنماست و VPN را روشن نمی‌کند. برای دسترسی بیرون از محل، ابتدا تونل WireGuard جداگانه برقرار کنید.
- پورت VNC را مستقیم روی اینترنت فوروارد نکنید. فقط از LAN یا VPN امن استفاده کنید.
- رمزها در SharedPreferences معمولی دستگاه ذخیره می‌شوند؛ از گوشی امن و قفل صفحه استفاده کنید.

ساخت APK:
فایل ZIP را در ریشه مخزن GitHub بارگذاری کنید. فایل workflow موجود در .github/workflows/build.yml نیز باید در مخزن باشد. سپس Actions > Build ALI SHAMS CONTROL > Run workflow را اجرا کنید و APK را از بخش Artifacts دریافت کنید.

Package: com.alishams.control
Application: ALI SHAMS CONTROL
Creator: ALI SHAMS
Contact: alireza10721@gmail.com
