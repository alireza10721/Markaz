# مرکز کار — نسخه ۳.۰ (WireGuard واقعی)

این نسخه به‌جای تونل نمایشی قبلی، از کتابخانه رسمی WireGuard Android و موتور wireguard-go استفاده می‌کند. برنامه فقط وقتی وضعیت «متصل» می‌دهد که موتور WireGuard کانفیگ را بپذیرد؛ تست UDP ساده یا ساخت TUN به‌تنهایی اتصال محسوب نمی‌شود.

## مهم: قبل از اتصال

این ZIP به‌تنهایی نمی‌تواند روتر شما را از راه دور تغییر دهد. برای فعال‌شدن ارتباط، باید یک‌بار رابط WireGuard و Peer متناظر روی MikroTik ساخته شود و کانفیگ هم‌کلید در برنامه وارد شود. PPTP فعلی را حذف یا تغییر ندهید.

مشخصات شناخته‌شده روتر: RouterOS 7.11.2، IP عمومی `185.158.172.150`، LAN برابر `192.168.10.0/24`، پورت پیشنهادی UDP `51820` و شبکه تونل `10.66.66.0/24`.

### تنظیمات MikroTik

اسکریپت آماده در `router/01-create-wireguard.rsc` و دستور افزودن گوشی در `router/02-add-phone-peer.txt` قرار دارد. اسکریپت فقط موارد جدید اضافه می‌کند و PPTP فعلی را حذف یا ویرایش نمی‌کند.

ابتدا در ترمینال روتر اجرا کنید:

```routeros
/interface wireguard add name=wg-markaz listen-port=51820 mtu=1420 comment="MarkazKar"
/ip address add address=10.66.66.1/24 interface=wg-markaz comment="MarkazKar VPN"
/ip firewall nat add chain=srcnat src-address=10.66.66.0/24 dst-address=192.168.10.0/24 action=masquerade comment="WG to office LAN"
```

کلید عمومی روتر را با این دستور ببینید:

```routeros
/interface wireguard print detail where name=wg-markaz
```

برنامه به‌صورت محلی یک جفت‌کلید برای همین نصب تولید می‌کند. کلید عمومی گوشی و دستور آماده ثبت Peer را از تنظیمات کپی کنید. برای Peer دستور زیر را با کلید عمومی واقعی جایگزین کنید:

```routeros
/interface wireguard peers add interface=wg-markaz public-key="CLIENT_PUBLIC_KEY" allowed-address=10.66.66.2/32 persistent-keepalive=25 comment="MarkazKar Android"
```

اگر Firewall Filter شما خالی است، قاعده ورودی جداگانه‌ای برای UDP 51820 لازم نیست؛ اگر بعداً سیاست Drop در زنجیره input اضافه شد، باید UDP 51820 پیش از Drop مجاز شود. همچنین مودم/روتر بالادستی باید UDP 51820 را به MikroTik هدایت کند، اگر MikroTik مستقیماً IP عمومی ندارد.

### کانفیگ گوشی

در تنظیمات برنامه، کلید عمومی روتر را وارد کنید. اگر فیلد کانفیگ کامل خالی باشد، برنامه کانفیگ گوشی را با کلید خصوصی ذخیره‌شده در همان دستگاه به‌صورت خودکار می‌سازد:

```ini
[Interface]
PrivateKey = CLIENT_PRIVATE_KEY
Address = 10.66.66.2/32
DNS = 192.168.10.1
MTU = 1420

[Peer]
PublicKey = ROUTER_PUBLIC_KEY
Endpoint = 185.158.172.150:51820
AllowedIPs = 192.168.10.0/24, 10.66.66.0/24
PersistentKeepalive = 25
```

کلید خصوصی گوشی داخل تنظیمات خصوصی برنامه روی همان دستگاه ذخیره می‌شود و در فایل‌های پروژه یا مخزن GitHub قرار نمی‌گیرد. آن را با کسی به اشتراک نگذارید.

## ساخت APK

مخزن را در GitHub آپلود کنید. GitHub Actions به‌صورت خودکار APK Debug می‌سازد و در Artifacts قرار می‌دهد. فایل `gradlew` در پروژه اولیه وجود نداشت؛ Workflow آن را در runner ایجاد می‌کند.

## دسترسی به LAN

پس از اتصال WireGuard، مسیر `192.168.10.0/24` از تونل عبور می‌کند. TeamViewer فقط در صورتی به دستگاه می‌رسد که خود TeamViewer روی کامپیوتر مقصد فعال و شناسه صحیح باشد. صفحه وب NVR نیز از طریق مرورگر باز می‌شود؛ پخش زنده و کنترل PTZ هنوز درون‌برنامه‌ای پیاده‌سازی نشده است.

## رفع خطا

- `کانفیگ WireGuard وارد نشده`: کانفیگ کامل را در تنظیمات قرار دهید.
- `VPN_NOT_AUTHORIZED`: مجوز اتصال VPN اندروید را تأیید کنید.
- `DNS_RESOLUTION_FAILURE`: آدرس Endpoint یا اینترنت گوشی را بررسی کنید.
- Handshake انجام نمی‌شود: UDP 51820، IP عمومی، Peer و کلیدهای دو طرف را بررسی کنید.

کتابخانه WireGuard از Maven Central و پروژه رسمی WireGuard Android استفاده می‌شود.
