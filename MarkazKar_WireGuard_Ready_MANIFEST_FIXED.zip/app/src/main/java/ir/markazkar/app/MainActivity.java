package ir.markazkar.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private final int navy = Color.rgb(15, 28, 58);
    private final int navyDark = Color.rgb(10, 20, 40);
    private final int teal = Color.rgb(45, 212, 191);
    private final int tealDark = Color.rgb(20, 184, 166);
    private final int ink = Color.rgb(30, 41, 59);
    private final int muted = Color.rgb(100, 116, 139);
    private final int bg = Color.rgb(240, 244, 248);
    private final int success = Color.rgb(16, 185, 129);
    private final int danger = Color.rgb(239, 68, 68);
    private final int warning = Color.rgb(245, 158, 11);

    private Prefs prefs;
    private TextView vpnStatusDot;
    private TextView vpnStatusText;
    private TextView vpnServerInfo;
    private Button btnVpn;
    private LinearLayout pcListContainer;
    private TextView cameraIpText;
    private TextView cameraStatusText;

    private boolean vpnConnected = false;

    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String state = intent.getStringExtra(MarkazVpnService.EXTRA_STATE);
            if (state == null) return;
            runOnUiThread(() -> updateVpnUi(state, intent.getStringExtra("error")));
        }
    };

    private ActivityResultLauncher<Intent> vpnPermissionLauncher;
    private ActivityResultLauncher<Intent> settingsLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new Prefs(this);

        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        vpnPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        startVpnService();
                    } else {
                        Toast.makeText(this, "مجوز VPN رد شد", Toast.LENGTH_SHORT).show();
                        updateVpnUi(MarkazVpnService.STATE_DISCONNECTED, null);
                    }
                });

        settingsLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> refreshUiFromPrefs());

        buildUi();
        registerVpnReceiver();
        // همگام‌سازی وضعیت فعلی
        updateVpnUi(MarkazVpnService.getCurrentState(), MarkazVpnService.getLastError());
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(vpnReceiver);
        } catch (Exception ignored) {
        }
        super.onDestroy();
    }

    private void registerVpnReceiver() {
        IntentFilter filter = new IntentFilter(MarkazVpnService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(vpnReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(vpnReceiver, filter);
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bg);
        scroll.setFillViewport(true);

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(16), dp(16), dp(16), dp(32));
        scroll.addView(page);

        // ===== Header =====
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(18), dp(20), dp(18), dp(20));
        header.setBackground(round(navy, 20));

        TextView logo = makeText("◈", 32, teal, true);
        header.addView(logo);

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);
        titleCol.setPadding(dp(12), 0, 0, 0);
        LinearLayout.LayoutParams titleLp = lp(0, -2);
        titleLp.weight = 1;
        titleCol.setLayoutParams(titleLp);
        titleCol.addView(makeText("مرکز کار", 24, Color.WHITE, true));
        titleCol.addView(makeText("مدیریت ارتباطات و نظارت", 13, Color.rgb(165, 180, 205), false));
        header.addView(titleCol);

        Button btnSettings = makeButton("⚙", Color.rgb(30, 50, 90), Color.WHITE);
        btnSettings.setTextSize(18);
        btnSettings.setOnClickListener(v ->
                settingsLauncher.launch(new Intent(this, SettingsActivity.class)));
        header.addView(btnSettings, lp(dp(48), dp(48)));

        page.addView(header, lp(-1, -2));
        addGap(page, 16);

        // ===== VPN Card =====
        LinearLayout vpnCard = card(page);
        LinearLayout vpnHeader = new LinearLayout(this);
        vpnHeader.setOrientation(LinearLayout.HORIZONTAL);
        vpnHeader.setGravity(Gravity.CENTER_VERTICAL);

        vpnStatusDot = new TextView(this);
        vpnStatusDot.setText("●");
        vpnStatusDot.setTextSize(18);
        vpnStatusDot.setTextColor(muted);
        vpnHeader.addView(vpnStatusDot);

        TextView vpnTitle = makeText("  اتصال امن WireGuard", 17, navy, true);
        vpnHeader.addView(vpnTitle);
        vpnCard.addView(vpnHeader);
        addGap(vpnCard, 10);

        vpnStatusText = makeText("وضعیت: قطع", 15, ink, true);
        vpnCard.addView(vpnStatusText);

        vpnServerInfo = makeText("سرور WireGuard: " + prefs.getVpnServer() + ":" + prefs.getVpnPort(), 13, muted, false);
        vpnCard.addView(vpnServerInfo);
        addGap(vpnCard, 14);

        btnVpn = makeButton("اتصال VPN", teal, navy);
        btnVpn.setTextSize(15);
        btnVpn.setOnClickListener(v -> toggleVpn());
        vpnCard.addView(btnVpn, lp(-1, dp(50)));

        addGap(page, 14);

        // ===== Computers Card =====
        LinearLayout pcCard = card(page);
        pcCard.addView(makeText("کامپیوترهای محل کار", 17, navy, true));
        addGap(pcCard, 4);
        TextView pcHint = makeText("پس از اتصال VPN می‌توانید با TeamViewer وصل شوید", 12, muted, false);
        pcCard.addView(pcHint);
        addGap(pcCard, 12);

        pcListContainer = new LinearLayout(this);
        pcListContainer.setOrientation(LinearLayout.VERTICAL);
        pcCard.addView(pcListContainer);

        rebuildPcList();

        addGap(page, 14);

        // ===== Cameras Card =====
        LinearLayout camCard = card(page);
        camCard.addView(makeText("دوربین‌های Dahua / NVR", 17, navy, true));
        addGap(camCard, 8);

        cameraIpText = makeText("آی‌پی: " + prefs.getCameraIp() + ":" + prefs.getCameraPort(), 14, ink, true);
        camCard.addView(cameraIpText);
        addGap(camCard, 4);

        cameraStatusText = makeText("برای تغییر آی‌پی از تنظیمات استفاده کنید", 12, muted, false);
        camCard.addView(cameraStatusText);
        addGap(camCard, 12);

        // Grid buttons
        LinearLayout grids = new LinearLayout(this);
        grids.setOrientation(LinearLayout.HORIZONTAL);
        String[] layouts = {"۱", "۴", "۹", "۱۶", "۳۲"};
        for (String s : layouts) {
            Button b = makeButton(s, Color.rgb(241, 245, 249), navy);
            b.setTextSize(14);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
            p.setMargins(dp(3), 0, dp(3), 0);
            grids.addView(b, p);
            b.setOnClickListener(v -> openCameraLayout(s));
        }
        camCard.addView(grids);
        addGap(camCard, 10);

        Button openCam = makeButton("باز کردن پنل دوربین", Color.rgb(59, 130, 246), Color.WHITE);
        openCam.setOnClickListener(v -> openCameraWeb());
        camCard.addView(openCam, lp(-1, dp(46)));

        addGap(page, 14);

        // ===== Info Card =====
        LinearLayout infoCard = card(page);
        infoCard.addView(makeText("راهنما", 17, navy, true));
        addGap(infoCard, 8);
        infoCard.addView(makeText(
                "۱. کلید عمومی MikroTik را در تنظیمات وارد کنید و Peer گوشی را روی روتر ثبت کنید.\n" +
                        "۲. روی «اتصال VPN» بزنید و مجوز سیستم را تأیید کنید.\n" +
                        "۳. پس از اتصال، روی هر کامپیوتر بزنید تا TeamViewer باز شود.\n" +
                        "۴. آی‌پی دوربین را هم از تنظیمات می‌توانید تغییر دهید.",
                13, muted, false));

        setContentView(scroll);
    }

    private void rebuildPcList() {
        pcListContainer.removeAllViews();
        List<Prefs.PcItem> list = prefs.getPcList();
        int show = Math.min(list.size(), 8); // نمایش اولیه ۸ تا
        for (int i = 0; i < show; i++) {
            Prefs.PcItem pc = list.get(i);
            addPcRowView(pc);
        }
        if (list.size() > show) {
            Button more = makeButton("نمایش همه (" + list.size() + " دستگاه)", Color.rgb(241, 245, 249), navy);
            more.setOnClickListener(v -> {
                pcListContainer.removeAllViews();
                for (Prefs.PcItem pc : list) {
                    addPcRowView(pc);
                }
            });
            LinearLayout.LayoutParams p = lp(-1, dp(42));
            p.topMargin = dp(6);
            pcListContainer.addView(more, p);
        }
    }

    private void addPcRowView(Prefs.PcItem pc) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable rowBg = round(Color.rgb(248, 250, 252), 12);
        rowBg.setStroke(dp(1), Color.rgb(226, 232, 240));
        row.setBackground(rowBg);
        LinearLayout.LayoutParams rowLp = lp(-1, -2);
        rowLp.bottomMargin = dp(8);
        pcListContainer.addView(row, rowLp);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams infoLp = lp(0, -2);
        infoLp.weight = 1;
        info.setLayoutParams(infoLp);

        info.addView(makeText(pc.name, 15, ink, true));
        String sub = pc.ip;
        if (pc.teamviewerId != null && !pc.teamviewerId.isEmpty()) {
            sub += "  •  TV: " + pc.teamviewerId;
        }
        info.addView(makeText(sub, 12, muted, false));
        row.addView(info);

        Button connect = makeButton("اتصال", teal, navy);
        connect.setTextSize(12);
        connect.setPadding(dp(12), 0, dp(12), 0);
        connect.setOnClickListener(v -> connectToPc(pc));
        row.addView(connect, lp(dp(80), dp(38)));
    }

    private void connectToPc(Prefs.PcItem pc) {
        if (!vpnConnected && !MarkazVpnService.isConnected()) {
            new AlertDialog.Builder(this)
                    .setTitle("VPN متصل نیست")
                    .setMessage("برای دسترسی به شبکه داخلی ابتدا باید VPN را وصل کنید.\n\nآیا می‌خواهید همین حالا وصل شوید؟")
                    .setPositiveButton("اتصال VPN", (d, w) -> toggleVpn())
                    .setNegativeButton("انصراف", null)
                    .show();
            return;
        }

        // اولویت با TeamViewer ID
        if (pc.teamviewerId != null && !pc.teamviewerId.trim().isEmpty()) {
            openTeamViewer(pc.teamviewerId.trim(), pc.name);
            return;
        }

        // اگر TeamViewer ID نبود، گزینه‌ها را نشان بده
        new AlertDialog.Builder(this)
                .setTitle(pc.name)
                .setMessage("شناسه TeamViewer ثبت نشده.\n\nآی‌پی داخلی: " + pc.ip +
                        "\n\nمی‌توانید TeamViewer را دستی باز کنید یا شناسه را در تنظیمات وارد کنید.")
                .setPositiveButton("باز کردن TeamViewer", (d, w) -> openTeamViewerApp())
                .setNeutralButton("کپی آی‌پی", (d, w) -> {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) {
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("ip", pc.ip));
                        Toast.makeText(this, "آی‌پی کپی شد: " + pc.ip, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("بستن", null)
                .show();
    }

    private void openTeamViewer(String partnerId, String name) {
        // روش‌های مختلف باز کردن TeamViewer
        String[] uris = {
                "teamviewerapi://goto/screen?device=" + partnerId,
                "teamviewer8://open?type=remotecontrol&partnerid=" + partnerId,
                "https://start.teamviewer.com/device/" + partnerId
        };

        boolean opened = false;
        for (String u : uris) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(u));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                opened = true;
                Toast.makeText(this, "در حال اتصال به " + name + " ...", Toast.LENGTH_SHORT).show();
                break;
            } catch (Exception ignored) {
            }
        }

        if (!opened) {
            // اگر هیچ کدام کار نکرد، اپ TeamViewer را باز کن
            openTeamViewerApp();
            Toast.makeText(this,
                    "شناسه: " + partnerId + "\nلطفاً در TeamViewer وارد کنید",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void openTeamViewerApp() {
        try {
            Intent i = getPackageManager().getLaunchIntentForPackage("com.teamviewer.teamviewer.market.mobile");
            if (i == null) {
                i = getPackageManager().getLaunchIntentForPackage("com.teamviewer.quicksupport.market");
            }
            if (i != null) {
                startActivity(i);
            } else {
                // هدایت به پلی‌استور
                startActivity(new Intent(Intent.ACTION_VIEW,
                        Uri.parse("market://details?id=com.teamviewer.teamviewer.market.mobile")));
            }
        } catch (Exception e) {
            Toast.makeText(this, "TeamViewer نصب نیست. از پلی‌استور نصب کنید.", Toast.LENGTH_LONG).show();
        }
    }

    private void openCameraLayout(String layout) {
        Toast.makeText(this,
                "چیدمان " + layout + " انتخاب شد.\nپس از اتصال به NVR فعال می‌شود.",
                Toast.LENGTH_SHORT).show();
    }

    private void openCameraWeb() {
        String ip = prefs.getCameraIp();
        String port = prefs.getCameraPort();
        String url = "http://" + ip + (port.equals("80") ? "" : ":" + port);
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "نتوانست مرورگر را باز کند: " + url, Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- VPN Logic ----------

    private void toggleVpn() {
        if (MarkazVpnService.isConnected() ||
                MarkazVpnService.STATE_CONNECTING.equals(MarkazVpnService.getCurrentState())) {
            // قطع کردن
            Intent i = new Intent(this, MarkazVpnService.class);
            i.setAction(MarkazVpnService.ACTION_DISCONNECT);
            startService(i);
            updateVpnUi(MarkazVpnService.STATE_DISCONNECTED, null);
        } else {
            // درخواست مجوز و اتصال
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) {
                updateVpnUi(MarkazVpnService.STATE_CONNECTING, null);
                vpnPermissionLauncher.launch(prepare);
            } else {
                startVpnService();
            }
        }
    }

    private void startVpnService() {
        updateVpnUi(MarkazVpnService.STATE_CONNECTING, null);
        Intent i = new Intent(this, MarkazVpnService.class);
        i.setAction(MarkazVpnService.ACTION_CONNECT);
        ContextCompat.startForegroundService(this, i);
    }

    private void updateVpnUi(String state, String error) {
        vpnConnected = MarkazVpnService.STATE_CONNECTED.equals(state);

        switch (state) {
            case MarkazVpnService.STATE_CONNECTED:
                vpnStatusDot.setTextColor(success);
                vpnStatusText.setText("وضعیت: متصل ✓");
                vpnStatusText.setTextColor(success);
                btnVpn.setText("قطع اتصال");
                btnVpn.setBackground(round(danger, 12));
                btnVpn.setTextColor(Color.WHITE);
                break;
            case MarkazVpnService.STATE_CONNECTING:
                vpnStatusDot.setTextColor(warning);
                vpnStatusText.setText("وضعیت: در حال اتصال...");
                vpnStatusText.setTextColor(warning);
                btnVpn.setText("صبر کنید...");
                btnVpn.setBackground(round(Color.rgb(203, 213, 225), 12));
                btnVpn.setTextColor(ink);
                break;
            case MarkazVpnService.STATE_ERROR:
                vpnStatusDot.setTextColor(danger);
                vpnStatusText.setText("خطا: " + (error != null ? error : "نامشخص"));
                vpnStatusText.setTextColor(danger);
                btnVpn.setText("تلاش مجدد");
                btnVpn.setBackground(round(teal, 12));
                btnVpn.setTextColor(navy);
                break;
            default:
                vpnStatusDot.setTextColor(muted);
                vpnStatusText.setText("وضعیت: قطع");
                vpnStatusText.setTextColor(ink);
                btnVpn.setText("اتصال VPN");
                btnVpn.setBackground(round(teal, 12));
                btnVpn.setTextColor(navy);
                break;
        }
    }

    private void refreshUiFromPrefs() {
        vpnServerInfo.setText("سرور WireGuard: " + prefs.getVpnServer() + ":" + prefs.getVpnPort());
        cameraIpText.setText("آی‌پی: " + prefs.getCameraIp() + ":" + prefs.getCameraPort());
        rebuildPcList();
    }

    // ---------- UI Helpers ----------

    private LinearLayout card(LinearLayout parent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(16), dp(16), dp(16));
        box.setBackground(round(Color.WHITE, 18));
        // سایه ساده با استروک
        GradientDrawable bg = round(Color.WHITE, 18);
        bg.setStroke(dp(1), Color.rgb(226, 232, 240));
        box.setBackground(bg);
        LinearLayout.LayoutParams p = lp(-1, -2);
        p.bottomMargin = dp(4);
        parent.addView(box, p);
        return box;
    }

    private TextView makeText(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setLineSpacing(dp(2), 1f);
        return t;
    }

    private Button makeButton(String s, int bgColor, int textColor) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(14);
        b.setTextColor(textColor);
        b.setAllCaps(false);
        b.setBackground(round(bgColor, 12));
        b.setStateListAnimator(null);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    private void addGap(LinearLayout l, int h) {
        View v = new View(this);
        l.addView(v, lp(1, dp(h)));
    }

    private int dp(int x) {
        return (int) (x * getResources().getDisplayMetrics().density + 0.5f);
    }
}
