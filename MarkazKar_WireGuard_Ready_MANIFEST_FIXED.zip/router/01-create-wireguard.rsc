# MarkazKar WireGuard — RouterOS 7.x
# Safe additive setup. Does not delete or edit existing PPTP users/rules.
/interface wireguard add name=wg-markaz listen-port=51820 mtu=1420 comment="MarkazKar WireGuard"
/ip address add address=10.66.66.1/24 interface=wg-markaz comment="MarkazKar VPN subnet"
/ip firewall nat add chain=srcnat src-address=10.66.66.0/24 dst-address=192.168.10.0/24 action=masquerade comment="MarkazKar WG to office LAN"
/ip firewall filter add chain=input action=accept protocol=udp dst-port=51820 comment="Allow WireGuard UDP"

# Then read the router public key:
# /interface wireguard print detail where name=wg-markaz
# Add the Android peer using the command in 02-add-phone-peer.txt.
